
import React, {useState} from  "react";
import Form from './componants/Form';
import TodoList from './componants/TodoList';
import './App.css';





function App() {
  const [inputText, setInputText] = useState("");
  const [todos, setTodos] = useState([]);

  return (
    <div className="App">
      <header>
        Ed's Todo List
      </header>
      <Form inputText={inputText} setInputText= {setInputText} todos={todos} setTodos={setTodos}/>
      <TodoList todos={todos} setTodos={setTodos} />
    </div>
  );
}

export default App;
